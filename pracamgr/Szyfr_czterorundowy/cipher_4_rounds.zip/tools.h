#ifndef __TOOLS_H__
#define __TOOLS_H__

int inline min( int a, int b )
{
	return a<b?a:b;
};

#endif